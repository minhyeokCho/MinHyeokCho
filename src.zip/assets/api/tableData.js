export default [
	{id:1, name:'최우식',age:20, addr:'서울', done:true},
	{id:2, name:'김다미',age:21, addr:'재주', done:false},
	{id:3, name:'김성철',age:22, addr:'경기', done:true},
	{id:4, name:'노의정',age:23, addr:'부산', done:false},
	{id:5, name:'박진주',age:24, addr:'전주', done:true},
]