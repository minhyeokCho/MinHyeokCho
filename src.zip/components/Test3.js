import React, { useState } from 'react';

const Test3 = () => {
	const [bgColor, setBgColor] = useState('tomato');
	const bgChange = () => {
		setBgColor(bgColor === 'tomato' ? 'blue' : 'tomato');
	};
	return (
		<div>
			<h3>div 클릭시 배경색을 pink -  blue 토글기능 </h3>
			<div style={{border:'1px solid black',padding:'30px',margin:'20px', fontSize:'20px', cursor:'pointer', backgroundColor:bgColor, color:'white'}}
			onClick={bgChange}
			>
				backgroundColor:{bgColor}
			</div>
		</div>
	);
};

export default Test3;