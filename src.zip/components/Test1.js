import React from 'react';

const Test1 = () => {
	//함수 영역
	const arr = ['fooe','exports','value','query','workbox']
	const data =[
		{id:1,name:'fooe'},
		{id:2,name:'exports'},
		{id:3,name:'value'},
		{id:4,name:'query'},
		{id:5,name:'workbox'}
	];

	return (
		<div>
			<h2>map - key</h2>
			<ul>
				{
					arr.map((item, index) => {
						return <li key={index}>
							{index} / {item}
						</li>
					})
				}
			</ul>

			<ul>
				{
					arr.map((item,index) => <li key={index}> {index} / {item}</li> )
				}
			</ul>
			<hr/>
			<ul>
				{
					data.map((item, index) => {
						return <li key={index}>
							{index + 1} / {item.name}
						</li> 
					})
				}
			</ul>
			<ul>
				{
					data.map(item => <li key={item.id}>{item.id} / {item.name}</li>)
				}
			</ul>
		</div>
	);
};

export default Test1;

/* 
	Array.map((현재값, 인덱스) => {
		return 반환값
	})
	Array.map((현재값, 인덱스) => 반환값);

	jsx map 출력할 경우
	key 반드시작성

고유값,식별 - 수정,삭제,추가 처리속도 빠르다
주민번호 ? " 주민번호", 고유값
key = 숫자, 문자

단 수정,삭제,추가 할경우 index 추천하지 않는다

index 는 단순히 출력만 할경우 사용

*/