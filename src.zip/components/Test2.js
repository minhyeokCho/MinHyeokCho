import React, { useState } from 'react';

const Test2 = () => {
	const [name, setName] = useState('홍길동');
	const [age, setAge] = useState('0');
	const [colors, setColor] = useState('pink');
	
	const onName1 = () => {
		setName('toysw')
	}
	const onName2 = () => {
		setName('ropiu')
	}
	const onName3 = () => {
		setName('dasum')
	}
	const onAge1 = () => {
		setAge(20)
	}
	const onAge2 = () => {
		setAge(15)
	}
	return (
		<div>
			<h2>useState : 값이 유동으로 변경 </h2>
			<h3 style={{color:colors}}>이름 : {name} / 나이 : {age}살 / 컬러 : {colors} </h3>
			<p>
				<button onClick={onName1}>toysw</button>
				<button onClick={onName2}>ropiu</button>
				<button onClick={onName3}>dasum</button>
			</p>
			<p>
				<button onClick={onAge1}>20</button>
				<button onClick={onAge2}>15</button>
			</p>
			<p>
				<button onClick={()=>setColor('red')} >red</button>
				<button onClick={()=>setColor('blue')}>blue</button>
				<button onClick={()=>setColor('green')}>green</button>
			</p>
		</div>
	);
};

export default Test2;

/* 

	Hooks - useState
	1. 렌더링 될때마다 내부것(변수, 함수)등 기억하지 못하고 새로만든다.
	화면에 새로 그려내는 방식
	다시 생성 초기화

	값을 내부에서 유지하기 위해서 - hook
	useXXXXXX

	*** useState - 값이 유동으로 변경할경우
	const [상태데이터, 상태값을 변경해주는 함수] = useState(초기값)
	const [state, setState] = useState(초기값)

	예)
	const [aaa, bbb] = useState(10);

	aaa = 10;
	bbb(값 or 수식);
	bbb(20)
	aaa = 20;

	새로운 state 변수를 선언하고, count라 부르겠습니다.
	const [사용자정의, 사용자정의이름] = useState(0);
	사용자정의이름 : 한글,영문

	const [상태변수, set상태함수] = useState('초기값');
	const [dog, setDog] = useState('강아지');
	초기값 ㅣ 문자, 숫자 , 논리값, [], {}

*/