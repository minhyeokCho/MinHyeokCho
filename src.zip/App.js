import React from 'react';
// import Test5 from './components/Test5';
import './assets/css/reset.css'
import TestBusiness from './Sample/TestBusiness';


const App = () => {
	return (
		<div>
			{/* <Test5/> */}
			<TestBusiness/>
		</div>
	);
};

export default App;